import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Layers,
  Settings,
  LogOut,
  Clock,
  History
} from "lucide-react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { useDatabase } from "../hooks/useDatabase";
import { setPdvShouldFocusOnMount, pdvNavigateAwayInterceptor, pdvModalOpen } from "../pages/PDV";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { db } = useDatabase();
  const [nomeLoja, setNomeLoja] = useState("Salgados Pro");


  useEffect(() => {
    if (!db) return;
    db.select("SELECT nome_loja FROM configuracoes WHERE id = 1")
      .then((res: unknown) => { const rows = res as any[]; if (rows.length > 0) setNomeLoja(rows[0].nome_loja || "Salgados Pro"); })
      .catch(() => {});
  }, [db, location.pathname]); // re-read on every page change so it updates after saving

  const menuItems = [
    { icon: LayoutDashboard, label: "DASHBOARD", path: "/" },
    { icon: ShoppingCart, label: "VENDA", path: "/pdv" },
    { icon: Package, label: "PRODUTOS", path: "/produtos" },
    { icon: Layers, label: "LOTES / VALID.", path: "/lotes" },
    { icon: Clock, label: "A PRAZO", path: "/aprazo" },
    { icon: History, label: "HISTORICO", path: "/historico" },
    { icon: Settings, label: "CONFIG", path: "/config" },
  ];

  useEffect(() => {
    const handleArrows = (e: KeyboardEvent) => {
      if (e.key === "Escape" && document.body.hasAttribute('data-esc-handled')) return;

      // Don't interfere while a PDV modal is open — PDV handles its own keys
      if (pdvModalOpen) return;

      const isSidebarFocused = document.activeElement?.closest('aside') !== null;
      const isMainFocused = document.activeElement?.closest('main') !== null;

      // Don't intercept keys while user is typing in an input inside main
      if (!isSidebarFocused && ["INPUT", "TEXTAREA"].includes((e.target as HTMLElement).tagName)) return;

      // ESC fallback ou ativação da sidebar se foco perdido (/aprazo gerencia isso internamente)
      if (!isSidebarFocused && !isMainFocused && e.key && location.pathname !== '/aprazo') {
        if (["Escape", "ArrowDown", "ArrowUp", "ArrowLeft"].includes(e.key)) {
            e.preventDefault();
            const activeSidebarLink = document.querySelector('aside nav a[class*="bg-luxury-orange"]') as HTMLElement;
            activeSidebarLink?.focus();
            return;
        }
      }

      // Logica da Sidebar (Quando foco esta na esquerda)
      if (isSidebarFocused) {
        const links = Array.from(document.querySelectorAll('aside nav a')) as HTMLElement[];
        const idx = links.indexOf(document.activeElement as HTMLElement);

        const goNext = e.key === "ArrowDown" || (e.key === "Tab" && !e.shiftKey);
        const goPrev = e.key === "ArrowUp" || (e.key === "Tab" && e.shiftKey);

        if (goNext) {
          e.preventDefault();
          if (idx >= 0 && idx < links.length - 1) {
            const nextPath = menuItems[idx + 1].path;
            if (location.pathname === '/pdv' && pdvNavigateAwayInterceptor?.()) return;
            navigate(nextPath);
            setTimeout(() => (document.querySelectorAll('aside nav a')[idx + 1] as HTMLElement)?.focus(), 0);
          }
        }

        if (goPrev) {
          e.preventDefault();
          if (idx > 0) {
            const prevPath = menuItems[idx - 1].path;
            if (location.pathname === '/pdv' && pdvNavigateAwayInterceptor?.()) return;
            navigate(prevPath);
            setTimeout(() => (document.querySelectorAll('aside nav a')[idx - 1] as HTMLElement)?.focus(), 0);
          }
        }

        if (e.key === "Enter") {
          e.preventDefault();
          const activeLink = document.activeElement as HTMLAnchorElement;
          const href = activeLink?.getAttribute('href');
          if (location.pathname === '/pdv' && href !== '/pdv' && pdvNavigateAwayInterceptor?.()) return;
          if (href === '/pdv') {
            setPdvShouldFocusOnMount(true);
            setTimeout(() => {
              const main = document.querySelector('main');
              const preferred = main?.querySelector('[data-autofocus]') as HTMLElement;
              const firstFocusable = main?.querySelector('input, button, select, [tabindex]:not([tabindex="-1"])') as HTMLElement;
              if (preferred) preferred.focus();
              else if (firstFocusable) firstFocusable.focus();
            }, 0);
          }
          // For all other pages: stay on sidebar, just navigate
        }
        return;
      }

      // Lógica do Main Content (Quando foco esta na direita)
      // Skip if a modal overlay is open (fixed inset-0 with z-index on body)
      const modalOpen = !!document.querySelector('body > div[style*="z-index"]');
      // /aprazo gerencia seu próprio ESC internamente
      const isAprazo = location.pathname === '/aprazo';
      if (isMainFocused && e.key === "Escape" && !modalOpen && !isAprazo) {
        if (location.pathname === '/pdv' && pdvNavigateAwayInterceptor?.()) {
          return; // PDV showed its own confirm modal
        }

        e.preventDefault();
        const activeSidebarLink = document.querySelector('aside nav a[class*="bg-luxury-orange"]') as HTMLElement;
        if (activeSidebarLink) {
            (document.activeElement as HTMLElement)?.blur();
            activeSidebarLink.focus();
        }
      }
    };
    window.addEventListener("keydown", handleArrows, true);
    return () => window.removeEventListener("keydown", handleArrows, true);
  }, [location.pathname, navigate]);

  return (
    <div className="flex h-screen w-screen bg-background text-white overflow-hidden font-sans selection:bg-luxury-orange/30">
      {/* Sidebar */}
      <aside className="w-56 border-r border-white/5 bg-black/20 flex flex-col p-4 shrink-0 relative z-20">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-10 h-10 bg-luxury-orange rounded-xl flex items-center justify-center shadow-lg shadow-luxury-orange/20 shrink-0">
            <ShoppingCart className="text-white" size={24} />
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-white to-white/60 bg-clip-text text-transparent truncate">
            {nomeLoja}
          </h1>
        </div>


        <nav className="flex-1 space-y-2">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={e => {
                if (location.pathname === '/pdv' && item.path !== '/pdv' && pdvNavigateAwayInterceptor?.()) {
                  e.preventDefault();
                }
              }}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl group focus:outline-none no-underline",
                location.pathname === item.path
                  ? "border border-luxury-orange/30 bg-luxury-orange/10 text-luxury-orange shadow-lg shadow-luxury-orange/5 hover:bg-luxury-orange hover:border-luxury-orange hover:text-white focus:bg-luxury-orange focus:border-luxury-orange focus:text-white focus:shadow-luxury-orange/20"
                  : "text-white/50 border border-transparent hover:bg-white/5 hover:text-white focus:bg-white/5 focus:text-white"
              )}
            >
              <item.icon size={20} className={cn(
                "transition-transform group-hover:scale-110",
                location.pathname === item.path ? "text-white" : "text-white/40 group-hover:text-white"
              )} />
              <span className="font-medium">{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="mt-auto pt-6 border-t border-white/5">
          <button className="flex items-center gap-3 px-4 py-3 rounded-xl text-red-400/60 hover:text-red-400 hover:bg-red-400/10 transition-all w-full">
            <LogOut size={20} />
            <span className="font-medium">Sair</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden bg-luxury-gradient p-8 relative">
        {/* Background Gradients - constrained with overflow-hidden on parent */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-luxury-orange/5 blur-[120px] rounded-full -mr-64 -mt-64 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-luxury-orange/5 blur-[120px] rounded-full -ml-64 -mb-64 pointer-events-none" />
        
        <div className="relative z-10 w-full h-full">
          {children}
        </div>
      </main>
    </div>
  );
}
