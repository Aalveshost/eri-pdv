import Database from "@tauri-apps/plugin-sql";

interface ItemVendaInput {
  produtoId: number;
  quantidade: number;
  precoUnitario: number;
}

export async function processarVendaFIFO(db: Database, items: ItemVendaInput[], metodoPagamento: string, totalVenda: number) {
  try {
    // 1. Criar a venda principal
    const resVenda = await db.execute(
      "INSERT INTO vendas (total_venda, metodo_pagamento) VALUES ($1, $2)",
      [totalVenda, metodoPagamento]
    );
    const vendaId = resVenda.lastInsertId;

    for (const item of items) {
      // 2. Buscar lotes disponíveis (FIFO)
      const lotes: any[] = await db.select(
        "SELECT * FROM lotes WHERE produto_id = $1 AND status = 'ativo' AND qtd_atual > 0 ORDER BY data_validade ASC",
        [item.produtoId]
      );

      let qtdFaltante = item.quantidade;

      for (const lote of lotes) {
        if (qtdFaltante <= 0) break;

        const qtdADeduzir = Math.min(lote.qtd_atual, qtdFaltante);
        
        // 3. Atualizar o lote
        await db.execute(
          "UPDATE lotes SET qtd_atual = qtd_atual - $1 WHERE id = $2",
          [qtdADeduzir, lote.id]
        );

        // Se o lote zerou, marcar como esgotado (opcional, mas bom pra filtros)
        if (lote.qtd_atual - qtdADeduzir === 0) {
          await db.execute("UPDATE lotes SET status = 'esgotado' WHERE id = $1", [lote.id]);
        }

        // 4. Registrar o item da venda vinculado a este lote específico
        await db.execute(
          `INSERT INTO venda_itens (venda_id, produto_id, lote_id, quantidade, preco_unitario, preco_custo) 
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [vendaId, item.produtoId, lote.id, qtdADeduzir, item.precoUnitario, lote.preco_custo]
        );

        qtdFaltante -= qtdADeduzir;
      }

      if (qtdFaltante > 0) {
        // Alerta: Venda realizada com estoque negativo ou insuficiente no sistema
        // Em um sistema real, poderíamos tratar isso bloqueando a venda ou criando um lote "ajuste".
        console.warn(`Estoque insuficiente para produto ${item.produtoId}. Faltam ${qtdFaltante} unidades.`);
      }
    }

    return { success: true, vendaId };
  } catch (err) {
    console.error("Erro ao processar venda FIFO:", err);
    throw err;
  }
}
