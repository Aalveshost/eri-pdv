import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  TrendingUp, Package, AlertTriangle, Calendar,
  ChevronRight, DollarSign, Trophy, X, Search,
} from "lucide-react";
import { createPortal } from "react-dom";
import { useDatabase } from "../hooks/useDatabase";
import { formatCurrency } from "../utils/currency";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)); }

interface StatItem {
  id: number;
  nome: string;
  data_validade: string;
  dias_restantes: number;
  qtd: number;
}

interface MaisVendido {
  produto_nome: string;
  total_quantidade: number;
  total_valor: number;
}

// ─── Date helpers ────────────────────────────────────────────────────────────
function getFirstDayOfMonth() {
  const n = new Date();
  return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-01`;
}
function getTodayIso() {
  const n = new Date();
  return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-${String(n.getDate()).padStart(2, "0")}`;
}
function isoToBr(iso: string) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}
function brToIso(br: string) {
  const parts = br.replace(/_/g, "").split("/");
  const [d, m, y] = parts;
  if (!d || !m || !y || y.length < 4) return "";
  return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
}
function isValidBr(br: string) {
  const clean = br.replace(/_/g, "");
  const [d, m, y] = clean.split("/").map(Number);
  return !!d && !!m && !!y && y > 1900 && y <= 2100 && m >= 1 && m <= 12 && d >= 1 && d <= 31;
}
function getTodayDigits() {
  const n = new Date();
  return String(n.getDate()).padStart(2, "0") + String(n.getMonth() + 1).padStart(2, "0") + String(n.getFullYear());
}

// ─── Auto-format DateInput (igual APrazo) ────────────────────────────────────
function DateInput({
  value, // DD/MM/YYYY string
  onChange,
  highlighted,
  externalRef,
  onKeyDown: externalKeyDown,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  highlighted?: boolean;
  externalRef?: React.RefObject<HTMLInputElement | null>;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  disabled?: boolean;
}) {
  const localRef = useRef<HTMLInputElement>(null);
  const inputRef = externalRef ?? localRef;

  const [digits, setDigits] = useState(() => {
    if (value && isValidBr(value)) return value.replace(/\//g, "");
    return getTodayDigits();
  });

  const displayValue = digits.slice(0, 2) + "/" + digits.slice(2, 4) + "/" + digits.slice(4, 8);

  // Sync when external value changes
  useEffect(() => {
    if (value && isValidBr(value)) {
      const raw = value.replace(/\//g, "");
      if (raw !== digits) setDigits(raw);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    const pos = input.selectionStart ?? 0;

    // Pass navigation keys up to parent first
    if (e.key === "Escape" || e.key === "Tab") {
      externalKeyDown?.(e);
      return;
    }

    if (/^\d$/.test(e.key)) {
      e.preventDefault();
      if (pos >= 8) return;
      const nd = digits.slice(0, pos) + e.key + digits.slice(pos + 1);
      setDigits(nd);
      const np = pos + 1;
      const dispPos = np <= 2 ? np : np <= 4 ? np + 1 : np + 2;
      setTimeout(() => input.setSelectionRange(dispPos, dispPos), 0);
      const br = nd.slice(0, 2) + "/" + nd.slice(2, 4) + "/" + nd.slice(4, 8);
      if (isValidBr(br)) onChange(br);
      return;
    }

    if (e.key === "Backspace") {
      e.preventDefault();
      if (pos === 0) return;
      const rawPos = pos <= 2 ? pos : pos <= 5 ? pos - 1 : pos - 2;
      const nd = digits.slice(0, rawPos - 1) + "_" + digits.slice(rawPos);
      setDigits(nd);
      const prevRaw = rawPos - 1;
      const dispPos = prevRaw <= 2 ? prevRaw : prevRaw <= 4 ? prevRaw + 1 : prevRaw + 2;
      setTimeout(() => input.setSelectionRange(dispPos, dispPos), 0);
      return;
    }

    if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      // Let arrow keys move cursor inside input OR bubble to parent
      // We let default behavior for L/R inside digits; parent captures via window handler
      return;
    }

    if (e.key === "Enter") {
      externalKeyDown?.(e);
      return;
    }

    e.preventDefault();
  };

  return (
    <input
      ref={inputRef}
      type="text"
      value={displayValue}
      onChange={() => {}}
      onKeyDown={handleKeyDown}
      maxLength={10}
      disabled={disabled}
      className={cn(
        "luxury-input h-8 text-xs w-32 text-center font-mono tracking-widest outline-none",
        highlighted ? "border-luxury-orange ring-1 ring-luxury-orange/50" : ""
      )}
    />
  );
}

// ─── Overlay ─────────────────────────────────────────────────────────────────
function Overlay({ onClose, zIndex = 300, children }: { onClose: () => void; zIndex?: number; children: React.ReactNode }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopPropagation(); onClose(); } };
    window.addEventListener("keydown", h, true);
    return () => window.removeEventListener("keydown", h, true);
  }, [onClose]);
  return createPortal(
    <div
      className="fixed inset-0 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm"
      style={{ zIndex }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      {children}
    </div>,
    document.body
  );
}

// ─── Popup "Ver Completo" com filtro próprio ──────────────────────────────────
function PopupTodosVendidos({
  db,
  defaultInicio,
  defaultFim,
  onClose,
}: {
  db: any;
  defaultInicio: string; // DD/MM/YYYY
  defaultFim: string;
  onClose: () => void;
}) {
  const [ini, setIni] = useState(defaultInicio);
  const [fim, setFim] = useState(defaultFim);
  const [lista, setLista] = useState<MaisVendido[]>([]);
  const [loading, setLoading] = useState(false);

  const iniRef = useRef<HTMLInputElement>(null);
  const fimRef = useRef<HTMLInputElement>(null);
  const buscarRef = useRef<HTMLButtonElement>(null);

  const buscar = useCallback(async (i: string, f: string) => {
    if (!db) return;
    const isoIni = brToIso(i);
    const isoFim = brToIso(f);
    if (!isoIni || !isoFim) return;
    setLoading(true);
    const query = `
      SELECT produto_nome, SUM(total_quantidade) as total_quantidade, SUM(total_valor) as total_valor
      FROM (
        SELECT p.nome as produto_nome, SUM(vi.quantidade) as total_quantidade,
          SUM(vi.quantidade * vi.preco_unitario) as total_valor
        FROM venda_itens vi JOIN vendas v ON v.id = vi.venda_id JOIN produtos p ON p.id = vi.produto_id
        WHERE date(v.data_venda) >= $1 AND date(v.data_venda) <= $2 AND v.status = 'completa'
        GROUP BY p.nome
        UNION ALL
        SELECT vi.produto_nome, SUM(vi.quantidade) as total_quantidade, SUM(vi.valor_total) as total_valor
        FROM vendas_prazo_itens vi JOIN vendas_prazo vp ON vp.id = vi.venda_id
        WHERE date(vp.data_venda) >= $1 AND date(vp.data_venda) <= $2
        GROUP BY vi.produto_nome
      )
      GROUP BY produto_nome ORDER BY total_quantidade DESC`;
    try {
      const res: MaisVendido[] = await db.select(query, [isoIni, isoFim]);
      setLista(res);
    } catch (err) { console.error(err); }
    setLoading(false);
  }, [db]);

  // Busca inicial ao abrir
  useEffect(() => { buscar(ini, fim); }, []);

  // Auto-focus data inicial ao abrir
  useEffect(() => {
    setTimeout(() => {
      iniRef.current?.focus();
      iniRef.current?.setSelectionRange(0, 0);
    }, 60);
  }, []);

  // Nav: seta direita/esquerda entre ini → fim → Buscar (capture phase)
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const active = document.activeElement;
      if (e.key === "ArrowRight") {
        if (active === iniRef.current) {
          e.preventDefault(); e.stopPropagation();
          fimRef.current?.focus();
          fimRef.current?.setSelectionRange(0, 0);
        } else if (active === fimRef.current) {
          e.preventDefault(); e.stopPropagation();
          buscarRef.current?.focus();
        }
      } else if (e.key === "ArrowLeft") {
        if (active === fimRef.current) {
          e.preventDefault(); e.stopPropagation();
          iniRef.current?.focus();
          iniRef.current?.setSelectionRange(0, 0);
        } else if (active === buscarRef.current) {
          e.preventDefault(); e.stopPropagation();
          fimRef.current?.focus();
          fimRef.current?.setSelectionRange(0, 0);
        }
      } else if (e.key === "Enter" && active === buscarRef.current) {
        e.preventDefault(); e.stopPropagation();
        buscar(ini, fim);
      }
    };
    window.addEventListener("keydown", handler, true);
    return () => window.removeEventListener("keydown", handler, true);
  }, [ini, fim, buscar]);


  return (
    <Overlay onClose={onClose}>
      <div className="glass-card w-full max-w-xl flex flex-col gap-4 p-6" style={{ maxHeight: "85vh" }}>
        <div className="flex justify-between items-center shrink-0">
          <h3 className="text-lg font-black italic uppercase tracking-tight flex items-center gap-2">
            <Trophy className="text-luxury-orange" size={18} /> Ranking Completo
          </h3>
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Filtro próprio */}
        <div className="flex items-center gap-2 shrink-0 bg-white/5 rounded-xl px-4 py-3 border border-white/10">
          <Search size={14} className="text-white/30 shrink-0" />
          <span className="text-xs text-white/40 uppercase font-bold tracking-widest">De</span>
          <DateInput externalRef={iniRef} value={ini} onChange={v => setIni(v)} />
          <span className="text-xs text-white/40 uppercase font-bold tracking-widest">até</span>
          <DateInput externalRef={fimRef} value={fim} onChange={v => setFim(v)} />
          <button
            ref={buscarRef}
            onClick={() => buscar(ini, fim)}
            className="ml-auto btn-primary h-8 px-4 text-xs focus:ring-2 focus:ring-white/30 outline-none"
          >
            Buscar
          </button>
        </div>

        <p className="text-xs text-white/30 uppercase font-bold tracking-widest shrink-0 -mt-1">
          {lista.length} produto{lista.length !== 1 ? "s" : ""} encontrado{lista.length !== 1 ? "s" : ""}
        </p>

        <div className="grid grid-cols-[1fr_auto_auto] gap-2 px-2 shrink-0">
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/30">Produto</span>
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/30 text-right w-14">Qtd</span>
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/30 text-right w-24">Total</span>
        </div>

        <div className="flex-1 overflow-y-auto space-y-1 pr-1">
          {loading && (
            <div className="glass-card p-8 text-center">
              <p className="text-white/20 italic tracking-widest uppercase text-xs">Carregando...</p>
            </div>
          )}
          {!loading && lista.length === 0 && (
            <div className="glass-card p-8 text-center border-dashed border-white/10">
              <p className="text-white/20 italic tracking-widest uppercase text-xs">Nenhuma venda no período</p>
            </div>
          )}
          {!loading && lista.map((item, i) => (
            <div key={item.produto_nome} className="px-2 py-2 grid grid-cols-[1fr_auto_auto] gap-2 items-center border-b border-white/5">
              <div className="flex items-center gap-2 min-w-0">
                <span className={cn("text-[10px] font-black w-5 text-center shrink-0",
                  i === 0 ? "text-yellow-400" : i === 1 ? "text-white/40" : i === 2 ? "text-orange-700" : "text-white/20")}>
                  {i + 1}
                </span>
                <span className="text-sm font-bold truncate">{item.produto_nome}</span>
              </div>
              <span className="text-sm font-mono text-white/60 text-right w-14">{item.total_quantidade}x</span>
              <span className="text-sm font-mono text-luxury-orange text-right w-24">R$ {formatCurrency(item.total_valor)}</span>
            </div>
          ))}
        </div>
      </div>
    </Overlay>
  );
}

// ════════════════════════════════════════════════════════════════════════════
export default function Dashboard() {
  const { db } = useDatabase();
  const navigate = useNavigate();

  const [stats, setStats] = useState({ vendasHoje: 0, lucroHoje: 0, totalEstoque: 0, itensVencendo: 0 });
  const [alertas, setAlertas] = useState<StatItem[]>([]);

  const [mvInicio, setMvInicio] = useState(isoToBr(getFirstDayOfMonth()));
  const [mvFim, setMvFim] = useState(isoToBr(getTodayIso()));
  const [maisVendidos, setMaisVendidos] = useState<MaisVendido[]>([]);
  const [showPopupVendidos, setShowPopupVendidos] = useState(false);

  // ─── Navegação ────────────────────────────────────────────────────────────
  // Zones: null | 'lotes' | 'ver-lotes' | 'mv-inicio' | 'mv-fim' | 'ver-completo' | 'mv-lista'
  type NavZone = null | "lotes" | "ver-lotes" | "mv-inicio" | "mv-fim" | "ver-completo" | "mv-lista";
  const [navZone, setNavZone] = useState<NavZone>(null);
  const [focusedLoteIdx, setFocusedLoteIdx] = useState<number | null>(null);
  const [focusedMvIdx, setFocusedMvIdx] = useState<number | null>(null);
  // inputActive: true = input de data está em modo edição (Enter ativou)
  const [inputActive, setInputActive] = useState(false);

  const loteRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const mvRefs = useRef<(HTMLDivElement | null)[]>([]);
  const mvInicioRef = useRef<HTMLInputElement>(null);
  const mvFimRef = useRef<HTMLInputElement>(null);
  const verLotesBtnRef = useRef<HTMLButtonElement>(null);
  const verCompletoBtnRef = useRef<HTMLButtonElement>(null);

  // ─── Popup editar lote ───────────────────────────────────────────────────
  const [editLote, setEditLote] = useState<StatItem | null>(null);
  const [editLoteForm, setEditLoteForm] = useState({ qtd: "", validade: "" });

  // ─── Data load ───────────────────────────────────────────────────────────
  const loadDashboard = async () => {
    if (!db) return;
    try {
      const vendas: any[] = await db.select(`
        SELECT SUM(total_venda) as total,
          SUM(total_venda - (SELECT SUM(quantidade * preco_custo) FROM venda_itens vi WHERE vi.venda_id = v.id)) as lucro
        FROM vendas v WHERE date(data_venda) = date('now')`);
      const estoque: any[] = await db.select("SELECT SUM(qtd_atual) as total FROM lotes WHERE status = 'ativo'");
      const config: any[] = await db.select("SELECT dias_alerta_validade FROM configuracoes WHERE id = 1");
      const dias = config[0]?.dias_alerta_validade || 5;
      const vencendo: any[] = await db.select(`
        SELECT l.id, p.nome, l.data_validade, l.qtd_atual as qtd,
          (julianday(l.data_validade) - julianday('now')) as dias_restantes
        FROM lotes l JOIN produtos p ON l.produto_id = p.id
        WHERE l.status = 'ativo' AND l.qtd_atual > 0
          AND (julianday(l.data_validade) - julianday('now')) <= ${dias}
        ORDER BY l.data_validade ASC`);
      setStats({
        vendasHoje: vendas[0]?.total || 0,
        lucroHoje: vendas[0]?.lucro || 0,
        totalEstoque: estoque[0]?.total || 0,
        itensVencendo: vencendo.length,
      });
      setAlertas(vencendo);
    } catch (err) { console.error("Erro no Dashboard:", err); }
  };

  const loadMaisVendidos = useCallback(async () => {
    if (!db) return;
    const isoIni = brToIso(mvInicio);
    const isoFim = brToIso(mvFim);
    if (!isoIni || !isoFim) return;
    const query = `
      SELECT produto_nome, SUM(total_quantidade) as total_quantidade, SUM(total_valor) as total_valor
      FROM (
        SELECT p.nome as produto_nome, SUM(vi.quantidade) as total_quantidade,
          SUM(vi.quantidade * vi.preco_unitario) as total_valor
        FROM venda_itens vi JOIN vendas v ON v.id = vi.venda_id JOIN produtos p ON p.id = vi.produto_id
        WHERE date(v.data_venda) >= $1 AND date(v.data_venda) <= $2 AND v.status = 'completa'
        GROUP BY p.nome
        UNION ALL
        SELECT vi.produto_nome, SUM(vi.quantidade) as total_quantidade, SUM(vi.valor_total) as total_valor
        FROM vendas_prazo_itens vi JOIN vendas_prazo vp ON vp.id = vi.venda_id
        WHERE date(vp.data_venda) >= $1 AND date(vp.data_venda) <= $2
        GROUP BY vi.produto_nome
      )
      GROUP BY produto_nome ORDER BY total_quantidade DESC`;
    try {
      const all: MaisVendido[] = await db.select(query + " LIMIT 10", [isoIni, isoFim]);
      setMaisVendidos(all);
    } catch (err) { console.error("Erro mais vendidos:", err); }
  }, [db, mvInicio, mvFim]);

  useEffect(() => { loadDashboard(); }, [db]);
  useEffect(() => { loadMaisVendidos(); }, [loadMaisVendidos]);

  // ─── Teclado ─────────────────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Popups abertos: Overlay já trata ESC, não interferir
      if (editLote || showPopupVendidos) return;

      // inputActive: modo edição do input de data
      if (inputActive) {
        if (e.key === "Enter" || e.key === "Escape") {
          e.preventDefault(); e.stopPropagation();
          setInputActive(false);
          mvInicioRef.current?.blur();
          mvFimRef.current?.blur();
          setTimeout(() => loadMaisVendidos(), 0);
        }
        return;
      }

      // ESC: sai da zona (se houver); senão Layout trata (foca sidebar)
      if (e.key === "Escape") {
        if (navZone !== null) {
          e.preventDefault(); e.stopPropagation();
          setNavZone(null); setFocusedLoteIdx(null); setFocusedMvIdx(null);
          mvInicioRef.current?.blur(); mvFimRef.current?.blur();
        }
        return;
      }

      // Enter sem zona → primeiro lote (ou mv-inicio se não houver)
      if (e.key === "Enter" && navZone === null) {
        e.preventDefault(); e.stopPropagation();
        if (alertas.length > 0) {
          setNavZone("lotes"); setFocusedLoteIdx(0);
          setTimeout(() => loteRefs.current[0]?.focus(), 0);
        } else {
          setNavZone("mv-inicio");
        }
        return;
      }

      // ── Zona: lotes ──────────────────────────────────────────────────
      if (navZone === "lotes" && focusedLoteIdx !== null) {
        if (e.key === "ArrowDown") {
          e.preventDefault(); e.stopPropagation();
          if (focusedLoteIdx < alertas.length - 1) {
            const next = focusedLoteIdx + 1;
            setFocusedLoteIdx(next);
            setTimeout(() => loteRefs.current[next]?.focus(), 0);
          } else {
            // Último lote → vai para mv-inicio (sem focar input)
            setNavZone("mv-inicio"); setFocusedLoteIdx(null);
            loteRefs.current[focusedLoteIdx]?.blur();
          }
        } else if (e.key === "ArrowUp") {
          e.preventDefault(); e.stopPropagation();
          if (focusedLoteIdx > 0) {
            const prev = focusedLoteIdx - 1;
            setFocusedLoteIdx(prev);
            setTimeout(() => loteRefs.current[prev]?.focus(), 0);
          } else {
            // Primeiro lote → sobe para ver-lotes
            setNavZone("ver-lotes"); setFocusedLoteIdx(null);
            setTimeout(() => verLotesBtnRef.current?.focus(), 0);
          }
        } else if (e.key === "ArrowRight") {
          // Seta direita em lote → vai para input data inicial
          e.preventDefault(); e.stopPropagation();
          loteRefs.current[focusedLoteIdx]?.blur();
          setNavZone("mv-inicio"); setFocusedLoteIdx(null);
        } else if (e.key === "Enter") {
          e.preventDefault(); e.stopPropagation();
          const lote = alertas[focusedLoteIdx];
          if (lote) openEditLote(lote);
        }
        return;
      }

      // ── Zona: ver-lotes ──────────────────────────────────────────────
      if (navZone === "ver-lotes") {
        if (e.key === "ArrowDown") {
          e.preventDefault(); e.stopPropagation();
          if (alertas.length > 0) {
            setNavZone("lotes"); setFocusedLoteIdx(0);
            setTimeout(() => loteRefs.current[0]?.focus(), 0);
          }
        } else if (e.key === "Enter") {
          e.preventDefault(); e.stopPropagation();
          navigate("/lotes");
        }
        return;
      }

      // ── Zona: mv-inicio ──────────────────────────────────────────────
      // Input NÃO tem focus enquanto inputActive=false — apenas destacado.
      // Enter → ativa edição (foca input)
      // Seta direita → vai para mv-fim
      // Seta esquerda → volta para lotes (se houver)
      // Seta baixo → vai para mv-lista
      // Seta cima → volta para ver-lotes
      if (navZone === "mv-inicio") {
        if (e.key === "Enter") {
          e.preventDefault(); e.stopPropagation();
          setInputActive(true);
          setTimeout(() => { mvInicioRef.current?.focus(); mvInicioRef.current?.setSelectionRange(0, 0); }, 0);
        } else if (e.key === "ArrowRight") {
          e.preventDefault(); e.stopPropagation();
          setNavZone("mv-fim");
        } else if (e.key === "ArrowLeft") {
          e.preventDefault(); e.stopPropagation();
          if (alertas.length > 0) {
            setNavZone("lotes"); setFocusedLoteIdx(alertas.length - 1);
            setTimeout(() => loteRefs.current[alertas.length - 1]?.focus(), 0);
          }
        } else if (e.key === "ArrowUp") {
          e.preventDefault(); e.stopPropagation();
          setNavZone("ver-lotes");
          setTimeout(() => verLotesBtnRef.current?.focus(), 0);
        } else if (e.key === "ArrowDown") {
          e.preventDefault(); e.stopPropagation();
          if (maisVendidos.length > 0) {
            setNavZone("mv-lista"); setFocusedMvIdx(0);
            setTimeout(() => mvRefs.current[0]?.focus(), 0);
          }
        }
        return;
      }

      // ── Zona: mv-fim ─────────────────────────────────────────────────
      // Seta esquerda → volta para mv-inicio
      // Seta direita → vai para ver-completo (está à direita)
      // Seta cima → volta para mv-inicio
      // Seta baixo → vai para mv-lista
      // Enter → ativa edição
      if (navZone === "mv-fim") {
        if (e.key === "Enter") {
          e.preventDefault(); e.stopPropagation();
          setInputActive(true);
          setTimeout(() => { mvFimRef.current?.focus(); mvFimRef.current?.setSelectionRange(0, 0); }, 0);
        } else if (e.key === "ArrowLeft") {
          e.preventDefault(); e.stopPropagation();
          setNavZone("mv-inicio");
        } else if (e.key === "ArrowRight") {
          // Ver completo está à direita
          e.preventDefault(); e.stopPropagation();
          setNavZone("ver-completo");
          setTimeout(() => verCompletoBtnRef.current?.focus(), 0);
        } else if (e.key === "ArrowUp") {
          e.preventDefault(); e.stopPropagation();
          setNavZone("mv-inicio");
        } else if (e.key === "ArrowDown") {
          e.preventDefault(); e.stopPropagation();
          if (maisVendidos.length > 0) {
            setNavZone("mv-lista"); setFocusedMvIdx(0);
            setTimeout(() => mvRefs.current[0]?.focus(), 0);
          }
        }
        return;
      }

      // ── Zona: ver-completo ───────────────────────────────────────────
      if (navZone === "ver-completo") {
        if (e.key === "Enter") {
          e.preventDefault(); e.stopPropagation();
          setShowPopupVendidos(true);
        } else if (e.key === "ArrowLeft") {
          // Volta para mv-fim (está à esquerda)
          e.preventDefault(); e.stopPropagation();
          setNavZone("mv-fim");
          verCompletoBtnRef.current?.blur();
        } else if (e.key === "ArrowDown") {
          e.preventDefault(); e.stopPropagation();
          if (maisVendidos.length > 0) {
            setNavZone("mv-lista"); setFocusedMvIdx(0);
            setTimeout(() => mvRefs.current[0]?.focus(), 0);
          }
          verCompletoBtnRef.current?.blur();
        }
        return;
      }

      // ── Zona: mv-lista ───────────────────────────────────────────────
      if (navZone === "mv-lista" && focusedMvIdx !== null) {
        if (e.key === "ArrowDown") {
          e.preventDefault(); e.stopPropagation();
          if (focusedMvIdx < maisVendidos.length - 1) {
            const next = focusedMvIdx + 1;
            setFocusedMvIdx(next);
            setTimeout(() => mvRefs.current[next]?.focus(), 0);
          }
        } else if (e.key === "ArrowUp") {
          e.preventDefault(); e.stopPropagation();
          if (focusedMvIdx > 0) {
            const prev = focusedMvIdx - 1;
            setFocusedMvIdx(prev);
            setTimeout(() => mvRefs.current[prev]?.focus(), 0);
          } else {
            setNavZone("mv-inicio"); setFocusedMvIdx(null);
            setTimeout(() => mvRefs.current[0]?.blur(), 0);
          }
        } else if (e.key === "Enter") {
          e.preventDefault(); e.stopPropagation();
          setShowPopupVendidos(true);
        }
        return;
      }
    };

    window.addEventListener("keydown", handler, true);
    return () => window.removeEventListener("keydown", handler, true);
  }, [navZone, focusedLoteIdx, focusedMvIdx, inputActive, alertas, maisVendidos, navigate, editLote, showPopupVendidos, mvInicio, mvFim]);

  // ─── Editar lote ─────────────────────────────────────────────────────────
  const openEditLote = (lote: StatItem) => {
    setEditLote(lote);
    setEditLoteForm({ qtd: String(lote.qtd), validade: lote.data_validade });
  };

  const saveEditLote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editLote || !db) return;
    const qtd = parseInt(editLoteForm.qtd) || 0;
    await db.execute("UPDATE lotes SET qtd_atual=$1, data_validade=$2 WHERE id=$3", [qtd, editLoteForm.validade, editLote.id]);
    setEditLote(null);
    loadDashboard();
    setTimeout(() => loteRefs.current[focusedLoteIdx ?? 0]?.focus(), 50);
  };

  const excluirLote = async () => {
    if (!editLote || !db) return;
    await db.execute("DELETE FROM lotes WHERE id=$1", [editLote.id]);
    setEditLote(null);
    loadDashboard();
  };

  const marcarVendido = async () => {
    if (!editLote || !db) return;
    await db.execute("UPDATE lotes SET qtd_atual=0, status='esgotado' WHERE id=$1", [editLote.id]);
    setEditLote(null);
    loadDashboard();
  };

  return (
    <div className="h-full flex flex-col gap-5 overflow-hidden">
      <header>
        <h2 className="text-3xl font-black italic uppercase tracking-tighter text-white">
          Dashboard <span className="text-luxury-orange">Geral</span>
        </h2>
      </header>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 shrink-0">
        <StatCard title="Vendas Hoje" value={`R$ ${formatCurrency(stats.vendasHoje)}`} icon={TrendingUp} color="orange" />
        <StatCard title="Lucro Líquido" value={`R$ ${formatCurrency(stats.lucroHoje)}`} icon={DollarSign} color="green" />
        <StatCard title="Estoque Total" value={`${stats.totalEstoque} un`} icon={Package} color="blue" />
        <StatCard title="Alertas Críticos" value={stats.itensVencendo.toString()} icon={AlertTriangle} color="red" highlight={stats.itensVencendo > 0} />
      </div>

      {/* Two columns */}
      <div className="flex-1 grid grid-cols-2 gap-4 overflow-hidden min-h-0">

        {/* Coluna Validade */}
        <div className="flex flex-col gap-3 overflow-hidden">
          <div className="flex justify-between items-center shrink-0">
            <h3 className="text-base font-black italic uppercase tracking-tight flex items-center gap-2">
              <Calendar className="text-luxury-orange" size={18} /> Atenção à Validade
            </h3>
            <button
              ref={verLotesBtnRef}
              tabIndex={-1}
              onClick={() => navigate("/lotes")}
              onFocus={() => setNavZone("ver-lotes")}
              className={cn(
                "text-luxury-orange text-xs font-bold uppercase tracking-widest hover:underline flex items-center gap-1 group outline-none rounded-md transition-all",
                navZone === "ver-lotes" ? "ring-1 ring-luxury-orange/50 px-2 py-0.5 bg-luxury-orange/5" : ""
              )}
            >
              Ver todos os lotes <ChevronRight size={13} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {alertas.length === 0 ? (
              <div className="glass-card p-8 text-center border-dashed border-white/10">
                <p className="text-white/20 italic tracking-widest uppercase text-xs">Nenhum alerta pendente</p>
              </div>
            ) : (
              alertas.map((item, i) => (
                <button
                  key={item.id}
                  ref={el => { loteRefs.current[i] = el; }}
                  tabIndex={-1}
                  onClick={() => openEditLote(item)}
                  onFocus={() => { setNavZone("lotes"); setFocusedLoteIdx(i); }}
                  className={cn(
                    "glass-card p-4 flex justify-between items-center w-full text-left transition-all outline-none",
                    navZone === "lotes" && focusedLoteIdx === i
                      ? "border-luxury-orange/50 bg-luxury-orange/5 ring-1 ring-luxury-orange/30"
                      : "hover:border-luxury-orange/30"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center font-black text-xs shrink-0",
                      item.dias_restantes <= 0 ? "bg-red-500/10 text-red-500" : "bg-yellow-500/10 text-yellow-500"
                    )}>
                      {item.dias_restantes <= 0 ? "EXP" : `${Math.ceil(item.dias_restantes)}d`}
                    </div>
                    <div>
                      <p className="font-bold text-sm">{item.nome}</p>
                      <p className="text-xs text-white/30 uppercase tracking-widest">Lote #{item.id} · {item.qtd} un</p>
                    </div>
                  </div>
                  <p className="font-mono text-xs bg-white/5 px-2 py-1 rounded shrink-0">
                    {new Date(item.data_validade + "T12:00:00").toLocaleDateString("pt-BR")}
                  </p>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Coluna Mais Vendidos */}
        <div className="flex flex-col gap-3 overflow-hidden">
          <div className="flex justify-between items-center shrink-0">
            <h3 className="text-base font-black italic uppercase tracking-tight flex items-center gap-2">
              <Trophy className="text-luxury-orange" size={18} /> Mais Vendidos
            </h3>
          </div>

          {/* "Ver completo" acima dos inputs de data — única ocorrência */}
          <div className="flex items-center gap-2 shrink-0 pr-2">
            <span className="text-xs text-white/40 uppercase font-bold tracking-widest">De</span>

            {/* Input data inicial — destacado pela zona, foco só com Enter */}
            <div className={cn(
              "rounded-lg transition-all",
              navZone === "mv-inicio" && !inputActive ? "ring-1 ring-luxury-orange/60 bg-luxury-orange/5" : ""
            )}>
              <DateInput
                externalRef={mvInicioRef}
                value={mvInicio}
                onChange={v => setMvInicio(v)}
                highlighted={navZone === "mv-inicio" && inputActive}
              />
            </div>

            <span className="text-xs text-white/40 uppercase font-bold tracking-widest">até</span>

            {/* Input data final */}
            <div className={cn(
              "rounded-lg transition-all",
              navZone === "mv-fim" && !inputActive ? "ring-1 ring-luxury-orange/60 bg-luxury-orange/5" : ""
            )}>
              <DateInput
                externalRef={mvFimRef}
                value={mvFim}
                onChange={v => setMvFim(v)}
                highlighted={navZone === "mv-fim" && inputActive}
              />
            </div>

            {/* Ver completo — único, à direita dos inputs */}
            <button
              ref={verCompletoBtnRef}
              tabIndex={-1}
              onClick={() => setShowPopupVendidos(true)}
              onFocus={() => setNavZone("ver-completo")}
              className={cn(
                "ml-auto text-xs font-bold uppercase tracking-widest flex items-center gap-1 transition-all outline-none rounded-md whitespace-nowrap",
                navZone === "ver-completo"
                  ? "text-luxury-orange ring-1 ring-luxury-orange/50 px-2 py-0.5 bg-luxury-orange/5"
                  : "text-white/40 hover:text-luxury-orange"
              )}
            >
              Ver completo <ChevronRight size={12} />
            </button>
          </div>

          {/* Table header */}
          <div className="grid grid-cols-[1fr_auto_auto] gap-2 px-3 shrink-0">
            <span className="text-[10px] font-bold uppercase tracking-widest text-white/30">Produto</span>
            <span className="text-[10px] font-bold uppercase tracking-widest text-white/30 text-right w-14">Qtd</span>
            <span className="text-[10px] font-bold uppercase tracking-widest text-white/30 text-right w-20">Total</span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1 pr-1">
            {maisVendidos.length === 0 ? (
              <div className="glass-card p-8 text-center border-dashed border-white/10">
                <p className="text-white/20 italic tracking-widest uppercase text-xs">Nenhuma venda no período</p>
              </div>
            ) : (
              maisVendidos.map((item, i) => (
                <div
                  key={item.produto_nome}
                  ref={el => { mvRefs.current[i] = el; }}
                  tabIndex={-1}
                  onFocus={() => { setNavZone("mv-lista"); setFocusedMvIdx(i); }}
                  className={cn(
                    "glass-card px-3 py-2.5 grid grid-cols-[1fr_auto_auto] gap-2 items-center outline-none transition-all cursor-default",
                    navZone === "mv-lista" && focusedMvIdx === i
                      ? "border-luxury-orange/50 bg-luxury-orange/5 ring-1 ring-luxury-orange/30"
                      : ""
                  )}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={cn("text-[10px] font-black w-5 text-center shrink-0",
                      i === 0 ? "text-yellow-400" : i === 1 ? "text-white/40" : i === 2 ? "text-orange-700" : "text-white/20")}>
                      {i + 1}
                    </span>
                    <span className="text-sm font-bold truncate">{item.produto_nome}</span>
                  </div>
                  <span className="text-sm font-mono text-white/60 text-right w-14">{item.total_quantidade}x</span>
                  <span className="text-sm font-mono text-luxury-orange text-right w-20">R$ {formatCurrency(item.total_valor)}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Popup Ver completo */}
      {showPopupVendidos && (
        <PopupTodosVendidos
          db={db}
          defaultInicio={mvInicio}
          defaultFim={mvFim}
          onClose={() => setShowPopupVendidos(false)}
        />
      )}

      {/* Popup Editar Lote */}
      {editLote && (
        <Overlay onClose={() => setEditLote(null)}>
          <div className="glass-card w-full max-w-sm p-6 flex flex-col gap-5">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-black italic uppercase text-luxury-orange">Editar Lote</h3>
                <p className="text-sm text-white/50 font-bold">{editLote.nome} · Lote #{editLote.id}</p>
              </div>
              <button onClick={() => setEditLote(null)} className="text-white/40 hover:text-white"><X size={20} /></button>
            </div>
            <form onSubmit={saveEditLote} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs uppercase tracking-widest text-white/40 font-bold mb-1.5">Quantidade Atual</label>
                <input
                  type="number"
                  min="0"
                  className="luxury-input w-full h-11 font-black text-lg"
                  value={editLoteForm.qtd}
                  onChange={e => setEditLoteForm(f => ({ ...f, qtd: e.target.value }))}
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest text-white/40 font-bold mb-1.5">Data de Validade</label>
                <input
                  type="date"
                  className="luxury-input w-full h-11"
                  value={editLoteForm.validade}
                  onChange={e => setEditLoteForm(f => ({ ...f, validade: e.target.value }))}
                />
              </div>
              <div className="flex gap-3 pt-2 border-t border-white/5">
                <button type="button" onClick={marcarVendido}
                  className="flex-1 h-10 text-xs font-bold uppercase tracking-widest rounded-xl border border-green-500/30 text-green-400 hover:bg-green-500/10 transition-all">
                  Marcar Vendido
                </button>
                <button type="button" onClick={excluirLote}
                  className="flex-1 h-10 text-xs font-bold uppercase tracking-widest rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-all">
                  Excluir
                </button>
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setEditLote(null)}
                  className="flex-1 h-11 border border-white/10 rounded-xl hover:bg-white/5 uppercase text-xs font-bold">
                  Cancelar
                </button>
                <button type="submit" className="btn-primary flex-1 h-11">Salvar</button>
              </div>
            </form>
          </div>
        </Overlay>
      )}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, highlight = false }: any) {
  const colors: any = {
    orange: "text-luxury-orange bg-luxury-orange/10 border-luxury-orange/20",
    green: "text-green-500 bg-green-500/10 border-green-500/20",
    blue: "text-blue-500 bg-blue-500/10 border-blue-500/20",
    red: "text-red-500 bg-red-500/10 border-red-500/20",
  };
  return (
    <div className={cn(
      "glass-card p-5 border-b-4 transition-all hover:translate-y-[-2px]",
      highlight ? "ring-2 ring-red-500/50" : "",
      color === "orange" ? "border-b-luxury-orange" : color === "green" ? "border-b-green-500" :
      color === "blue" ? "border-b-blue-500" : "border-b-red-500"
    )}>
      <div className="flex flex-col gap-3">
        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", colors[color])}>
          <Icon size={20} />
        </div>
        <div>
          <p className="text-white/40 text-[10px] uppercase font-black tracking-[0.2em] mb-1">{title}</p>
          <p className="text-2xl font-black italic tracking-tighter">{value}</p>
        </div>
      </div>
    </div>
  );
}
