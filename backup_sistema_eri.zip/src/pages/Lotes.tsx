import { useState, useEffect } from "react";
import { Plus, Calendar, Package, AlertTriangle, TrendingUp, X, Edit2 } from "lucide-react";
import { createPortal } from "react-dom";
import { useDatabase } from "../hooks/useDatabase";
import Modal from "../components/Modal";
import { handleCurrencyInput, parseCurrencyToNumber, formatCurrency } from "../utils/currency";

interface Lote {
  id: number;
  produto_id: number;
  produto_nome: string;
  data_fabricacao: string;
  data_validade: string;
  qtd_inicial: number;
  qtd_atual: number;
  preco_custo: number;
  status: string;
  dias_para_vencer: number;
}

interface Produto {
  id: number;
  nome: string;
  preco_custo: number;
  validade_padrao_dias: number;
}

export default function Lotes() {
  const { db } = useDatabase();
  const [lotes, setLotes] = useState<Lote[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [diasAlerta, setDiasAlerta] = useState(5);

  // Popup editar lote
  const [editLote, setEditLote] = useState<Lote | null>(null);
  const [editForm, setEditForm] = useState({ qtd: "", validade: "" });

  const openEdit = (l: Lote) => {
    setEditLote(l);
    setEditForm({ qtd: String(l.qtd_atual), validade: l.data_validade });
  };
  const saveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editLote || !db) return;
    const qtd = parseInt(editForm.qtd) || 0;
    await db.execute("UPDATE lotes SET qtd_atual=$1, data_validade=$2 WHERE id=$3", [qtd, editForm.validade, editLote.id]);
    setEditLote(null);
    loadData();
  };
  const excluirLote = async () => {
    if (!editLote || !db) return;
    if (!confirm(`Excluir Lote #${editLote.id} (${editLote.produto_nome})?`)) return;
    await db.execute("DELETE FROM lotes WHERE id=$1", [editLote.id]);
    setEditLote(null);
    loadData();
  };
  const marcarVendido = async () => {
    if (!editLote || !db) return;
    await db.execute("UPDATE lotes SET qtd_atual=0, status='esgotado' WHERE id=$1", [editLote.id]);
    setEditLote(null);
    loadData();
  };

  const [form, setForm] = useState({
    produto_id: "",
    data_fabricacao: new Date().toISOString().split('T')[0],
    data_validade: "",
    qtd_inicial: "",
    preco_custo: "0,00"
  });

  const loadData = async () => {
    if (!db) return;
    try {
      const config: any = await db.select("SELECT dias_alerta_validade FROM configuracoes WHERE id = 1");
      if (config.length > 0) setDiasAlerta(config[0].dias_alerta_validade);

      const prodRes: any[] = await db.select("SELECT id, nome, preco_custo, validade_padrao_dias FROM produtos WHERE ativo = 1");
      setProdutos(prodRes);

      const lotesRes: any[] = await db.select(`
        SELECT l.*, p.nome as produto_nome,
        (julianday(l.data_validade) - julianday('now')) as dias_para_vencer
        FROM lotes l
        JOIN produtos p ON l.produto_id = p.id
        WHERE l.qtd_atual > 0
        ORDER BY l.data_validade ASC
      `);
      setLotes(lotesRes);
    } catch (err) {
      console.error("Erro ao carregar dados:", err);
    }
  };

  useEffect(() => {
    loadData();
  }, [db]);

  const handleProductChange = (prodId: string) => {
    const product = produtos.find(p => p.id.toString() === prodId);
    if (product) {
      const validade = new Date();
      validade.setDate(validade.getDate() + product.validade_padrao_dias);
      
      setForm({
        ...form,
        produto_id: prodId,
        preco_custo: formatCurrency(product.preco_custo),
        data_validade: validade.toISOString().split('T')[0]
      });
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;

    try {
      const pCusto = parseCurrencyToNumber(form.preco_custo);
      await db.execute(
        "INSERT INTO lotes (produto_id, data_fabricacao, data_validade, qtd_inicial, qtd_atual, preco_custo, status) VALUES ($1, $2, $3, $4, $4, $5, 'ativo')",
        [parseInt(form.produto_id), form.data_fabricacao, form.data_validade, parseInt(form.qtd_inicial), pCusto]
      );
      setIsModalOpen(false);
      loadData();
    } catch (err) {
      alert("Erro ao registrar entrada de lote.");
    }
  };

  return (
    <div className="space-y-8 h-full flex flex-col">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black italic uppercase tracking-tighter text-white">Lotes & <span className="text-luxury-orange">Validade</span></h2>
          <p className="text-white/40">Controle a entrada e o vencimento da produção.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="btn-primary flex items-center gap-2 px-6 h-12"
        >
          <Plus size={20} />
          Entrada de Lote
        </button>
      </header>

      <div className="grid grid-cols-4 gap-6">
        <div className="glass-card p-6 flex items-center gap-4 border-l-4 border-luxury-orange">
          <Package className="text-luxury-orange" size={32} />
          <div>
            <p className="text-white/40 text-xs uppercase font-bold tracking-widest">Total em Estoque</p>
            <p className="text-2xl font-black">{lotes.reduce((acc, l) => acc + l.qtd_atual, 0)} <span className="text-sm font-normal text-white/40">un</span></p>
          </div>
        </div>
        <div className="glass-card p-6 flex items-center gap-4 border-l-4 border-yellow-500">
          <AlertTriangle className="text-yellow-500" size={32} />
          <div>
            <p className="text-white/40 text-xs uppercase font-bold tracking-widest">Alerta Validade</p>
            <p className="text-2xl font-black text-yellow-500">{lotes.filter(l => l.dias_para_vencer <= diasAlerta && l.dias_para_vencer > 0).length}</p>
          </div>
        </div>
        <div className="glass-card p-6 flex items-center gap-4 border-l-4 border-red-500">
          <TrendingUp className="text-red-500 rotate-180" size={32} />
          <div>
            <p className="text-white/40 text-xs uppercase font-bold tracking-widest">Vencidos/Hoje</p>
            <p className="text-2xl font-black text-red-500">{lotes.filter(l => l.dias_para_vencer <= 0).length}</p>
          </div>
        </div>
        <div className="glass-card p-6 flex items-center gap-4 border-l-4 border-blue-500">
          <TrendingUp className="text-blue-500" size={32} />
          <div>
            <p className="text-white/40 text-xs uppercase font-bold tracking-widest">Lotes Ativos</p>
            <p className="text-2xl font-black">{lotes.length}</p>
          </div>
        </div>
      </div>

      <div className="glass-card flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto">
          <table className="w-full text-left">
            <thead className="text-white/20 text-xs uppercase tracking-widest border-b border-white/5 sticky top-0 bg-luxury-dark-gray z-10">
              <tr>
                <th className="px-6 py-4 font-medium">Produto</th>
                <th className="px-6 py-4 font-medium text-center">Qtd. Atual</th>
                <th className="px-6 py-4 font-medium">Data Validade</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Investimento</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {lotes.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center text-white/10 italic uppercase tracking-[0.2em]">
                    Nenhum lote ativo em estoque
                  </td>
                </tr>
              ) : (
                lotes.map((l) => (
                  <tr key={l.id} className="hover:bg-white/5 transition-colors group cursor-pointer" onClick={() => openEdit(l)}>
                    <td className="px-6 py-4">
                      <p className="font-bold text-lg">{l.produto_nome}</p>
                      <p className="text-xs text-white/20 uppercase tracking-widest">Lote #{l.id}</p>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className="bg-white/5 px-4 py-2 rounded-lg font-black text-xl">
                        {l.qtd_atual}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Calendar size={16} className="text-white/20" />
                        <span className="font-bold">{new Date(l.data_validade + 'T12:00:00').toLocaleDateString('pt-BR')}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {l.dias_para_vencer <= 0 ? (
                        <span className="bg-red-500/20 text-red-500 px-3 py-1 rounded-full text-xs font-black uppercase tracking-tighter border border-red-500/20">Vencido</span>
                      ) : l.dias_para_vencer <= diasAlerta ? (
                        <span className="bg-yellow-500/20 text-yellow-500 px-3 py-1 rounded-full text-xs font-black uppercase tracking-tighter border border-yellow-500/20">Vence em {Math.ceil(l.dias_para_vencer)} dias</span>
                      ) : (
                        <span className="bg-green-500/20 text-green-500 px-3 py-1 rounded-full text-xs font-black uppercase tracking-tighter border border-green-500/20">Normal</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-white/40 font-mono text-sm">
                      R$ {formatCurrency(l.qtd_atual * l.preco_custo)}
                    </td>
                    <td className="px-4 py-4 text-right">
                      <button onClick={e => { e.stopPropagation(); openEdit(l); }}
                        className="opacity-0 group-hover:opacity-100 p-2 rounded-lg hover:bg-white/10 text-white/40 hover:text-white transition-all">
                        <Edit2 size={15} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Popup editar lote */}
      {editLote && createPortal(
        <div className="fixed inset-0 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm z-[300]"
          onClick={e => { if (e.target === e.currentTarget) setEditLote(null); }}>
          <div className="glass-card w-full max-w-sm p-6 flex flex-col gap-5" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-black italic uppercase text-luxury-orange">Editar Lote</h3>
                <p className="text-sm text-white/50 font-bold">{editLote.produto_nome} · Lote #{editLote.id}</p>
              </div>
              <button onClick={() => setEditLote(null)} className="text-white/40 hover:text-white"><X size={20} /></button>
            </div>
            <form onSubmit={saveEdit} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs uppercase tracking-widest text-white/40 font-bold mb-1.5">Quantidade Atual</label>
                <input type="number" min="0" className="luxury-input w-full h-11 font-black text-lg"
                  value={editForm.qtd} autoFocus
                  onChange={e => setEditForm(f => ({ ...f, qtd: e.target.value }))} />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest text-white/40 font-bold mb-1.5">Data de Validade</label>
                <input type="date" className="luxury-input w-full h-11"
                  value={editForm.validade}
                  onChange={e => setEditForm(f => ({ ...f, validade: e.target.value }))} />
              </div>
              <div className="flex gap-3 pt-2 border-t border-white/5">
                <button type="button" onClick={marcarVendido}
                  className="flex-1 h-10 text-xs font-bold uppercase tracking-widest rounded-xl border border-green-500/30 text-green-400 hover:bg-green-500/10 transition-all">
                  Marcar Vendido
                </button>
                <button type="button" onClick={excluirLote}
                  className="flex-1 h-10 text-xs font-bold uppercase tracking-widest rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-all">
                  Excluir
                </button>
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setEditLote(null)}
                  className="flex-1 h-11 border border-white/10 rounded-xl hover:bg-white/5 uppercase text-xs font-bold">
                  Cancelar
                </button>
                <button type="submit" className="btn-primary flex-1 h-11">Salvar</button>
              </div>
            </form>
          </div>
        </div>, document.body
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Nova Entrada de Lote"
      >
        <form 
          onSubmit={handleSave} 
          onKeyDown={(e) => { if (e.key === 'Enter') handleSave(e); }} 
          className="grid grid-cols-2 gap-6"
        >
          <div className="col-span-2">
            <label className="block text-xs uppercase tracking-widest text-white/40 font-bold mb-2">Produto</label>
            <select 
              required
              className="luxury-input w-full h-12 bg-luxury-dark-gray"
              value={form.produto_id}
              onChange={e => handleProductChange(e.target.value)}
            >
              <option value="">Selecione um produto...</option>
              {produtos.map(p => (
                <option key={p.id} value={p.id}>{p.nome}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-xs uppercase tracking-widest text-white/40 font-bold mb-2">Data Fabricação</label>
            <input 
              required
              type="date" 
              className="luxury-input w-full h-12"
              value={form.data_fabricacao}
              onChange={e => setForm({...form, data_fabricacao: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-widest text-luxury-orange/60 font-bold mb-2">Data Validade</label>
            <input 
              required
              type="date" 
              className="luxury-input w-full h-12 border-luxury-orange/20"
              value={form.data_validade}
              onChange={e => setForm({...form, data_validade: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-widest text-white/40 font-bold mb-2">Quantidade Inicial</label>
            <input 
              required
              type="number" 
              className="luxury-input w-full h-12 font-black text-xl"
              value={form.qtd_inicial}
              onChange={e => setForm({...form, qtd_inicial: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-widest text-red-500/60 font-bold mb-2">Preço de Custo Un. (R$)</label>
            <input 
              required
              type="text" 
              className="luxury-input w-full h-12 border-red-500/10 font-bold"
              value={form.preco_custo}
              onChange={e => setForm({...form, preco_custo: handleCurrencyInput(e.target.value)})}
            />
          </div>

          <div className="col-span-2 pt-6 border-t border-white/5 flex gap-4">
            <button 
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="flex-1 h-14 uppercase tracking-widest text-sm font-bold border border-white/10 rounded-xl hover:bg-white/5 transition-all"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="btn-primary flex-1 h-14"
            >
              Confirmar Entrada
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
